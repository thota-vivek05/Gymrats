# Task Assignment - GYMRATS (Group 41)

| Team Member | Role | Key Responsibilities |
|--------------|------|----------------------|
| Thota Vivek | SPOC / Full Stack Dev | Project setup, backend API, DB integration |
| Rahul Naskanti | Frontend Dev | UI design (HTML, CSS, JS) |
| Chedideepu Jayanth | Backend Dev | Express routes, async handling |
| Cheela Anvesh | DB Manager | MongoDB + SQLite schema setup |
| B Manoj | Tester | Validation + network testing |
